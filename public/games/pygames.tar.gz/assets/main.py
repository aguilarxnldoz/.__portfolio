

import pygame
import os
import asyncio
pygame.font.init()

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
WIDTH, HEIGHT = 1000, 700
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Game Start!")

cWIDTH = 135
cHEIGHT = 120

BACKGROUND = (230, 230, 250)
WHITE = (255, 255, 255)
DUB_COLOR = (255, 165, 0)

BORDER = pygame.Rect(WIDTH // 2 - 5, 0, 10, HEIGHT)



HP = pygame.font.SysFont('inkfree', 50)
DUB_SCREEN = pygame.font.SysFont('lucidasans', 100)
CONTROL_HINT = pygame.font.SysFont('lucidasans', 28)



pb_tracer = (220, 20, 60)
mb_tracer = (70, 130, 180)


fps = 60
speed = 7
fire_rate = 10
ammo = 1000

red_damage = pygame.USEREVENT + 1
blue_damage = pygame.USEREVENT + 2

mega = pygame.image.load(
    os.path.join(SCRIPT_DIR, 'cheena_slayer69', 'mm.png'))
megasize = pygame.transform.scale(mega,(cWIDTH, cHEIGHT))


proto = pygame.image.load(
    os.path.join(SCRIPT_DIR, 'cheena_slayer69', 'protoman1.png'))
protosize = pygame.transform.scale(proto,(cWIDTH, cHEIGHT))



def draw_window(blue, red, megabullets, protobullets, mega_health, proto_health, show_controls):
    WIN.fill((BACKGROUND))
    pygame.draw.rect(WIN, WHITE, BORDER)

    proto_HP = HP.render("HP: " + str(proto_health), 1, pb_tracer)
    mega_HP = HP.render("HP: " + str(mega_health), 1, mb_tracer)
    WIN.blit(proto_HP, (WIDTH - proto_HP.get_width()- 10, 10))
    WIN.blit(mega_HP, (10, 10))

    if show_controls:
        mega_controls = CONTROL_HINT.render("MOVE: WASD  SHOOT: SPACE", 1, mb_tracer)
        proto_controls = CONTROL_HINT.render("MOVE: ARROWS  SHOOT: /", 1, pb_tracer)
        WIN.blit(mega_controls, (30, HEIGHT - 60))
        WIN.blit(proto_controls, (WIDTH - proto_controls.get_width() - 30, HEIGHT - 60))


    WIN.blit(megasize,(blue.x , blue.y))
    WIN.blit(protosize,(red.x, red.y))

    for bullet in megabullets:
        pygame.draw.rect(WIN, mb_tracer, bullet)
    
    for bullet in protobullets:
        pygame.draw.rect(WIN, pb_tracer, bullet)


    pygame.display.update()



def control_protoman(pressed_keys, red):
    if pressed_keys[pygame.K_LEFT] and red.x - speed > BORDER.x + BORDER.width:
        red.x -= speed
    if pressed_keys[pygame.K_RIGHT] and red.x + speed + red.width < WIDTH:
        red.x += speed
    if pressed_keys[pygame.K_UP] and red.y - speed > 0:
        red.y -= speed
    if pressed_keys[pygame.K_DOWN] and red.y + speed + red.height < HEIGHT:
        red.y += speed


def control_megaman(pressed_keys, blue):
    if pressed_keys[pygame.K_a] and blue.x - speed > 0 : 
        blue.x -= speed
    if pressed_keys[pygame.K_d] and blue.x + speed + blue.width < BORDER.x :
        blue.x += speed
    if pressed_keys[pygame.K_w] and blue.y - speed > 0:
        blue.y -= speed
    if pressed_keys[pygame.K_s] and blue.y + speed + blue.height < HEIGHT:
        blue.y += speed 

def shoot(protobullets, megabullets, red, blue):
    for bullet in protobullets[:]:
        bullet.x -= fire_rate
        if blue.colliderect(bullet):
            pygame.event.post(pygame.event.Event(blue_damage))
            protobullets.remove(bullet)
        elif bullet.x + bullet.width < 0:
            protobullets.remove(bullet)

    for bullet in megabullets[:]:
        bullet.x += fire_rate
        if red.colliderect(bullet):
            pygame.event.post(pygame.event.Event(red_damage))
            megabullets.remove(bullet)
        elif bullet.x > WIDTH:
            megabullets.remove(bullet)
            
def draw_DUB(text):
    draw_text = DUB_SCREEN.render(text, 1, DUB_COLOR)
    WIN.blit(draw_text, (WIDTH / 2 - draw_text.get_width()/2, HEIGHT/2 - draw_text.get_height()/2))
    pygame.display.update()
    pygame.time.delay(5000)

async def main():
    blue = pygame.Rect(100, HEIGHT // 2 - cHEIGHT // 2, cWIDTH, cHEIGHT)
    red = pygame.Rect(WIDTH - cWIDTH - 100, HEIGHT // 2 - cHEIGHT // 2, cWIDTH, cHEIGHT)

    protobullets = []
    megabullets = []

    proto_health = 10
    mega_health = 10
    round_start_time = pygame.time.get_ticks()

    clock = pygame.time.Clock()
    run = True
    while run:
        clock.tick(fps)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
            
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_SLASH, pygame.K_KP_DIVIDE) and len(protobullets) < ammo:
                    bullet = pygame.Rect(red.x - 10, red.y + red.height//2 - 2, 10, 5)
                    protobullets.append(bullet)
                    


                if event.key == pygame.K_SPACE and len(megabullets) < ammo:
                    bullet = pygame.Rect(blue.x + blue.width, blue.y + blue.height//2 - 2, 10, 5)
                    megabullets.append(bullet)
                    
            
            if event.type == red_damage:
                proto_health = proto_health - 1
                

            if event.type == blue_damage:
                mega_health = mega_health - 1
                
        
        dub = ""
        if proto_health <= 0:
            dub = "MEGAMAN WINS!"
        
        if mega_health <= 0:
            dub = "PROTOMAN WINS!"
            
        if dub != "":
            draw_DUB(dub)
            break


        
        pressed_keys = pygame.key.get_pressed()
        control_megaman(pressed_keys, blue)
        control_protoman(pressed_keys, red)

        shoot(protobullets, megabullets, red, blue)

        show_controls = pygame.time.get_ticks() - round_start_time < 5000
        draw_window(blue, red, megabullets, protobullets, mega_health, proto_health, show_controls)
        await asyncio.sleep(0)


asyncio.run(main())
